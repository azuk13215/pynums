from Prime import *
from rest.rest_func import *
from pynums.rest.statistics import *
from rest.statistics import *
from digits import *
from core import *
from rest.Checking import *