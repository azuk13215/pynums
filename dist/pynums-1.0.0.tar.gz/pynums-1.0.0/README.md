'PyNums' - is a simple library for working
with numbers, createated by Andriy Zhuk.
if includes functions for:
- working with numbers ('SumDigits','ReverseNumber');

- checking('IsPrime');

- basic math('SumAll');

- statistics('difference).

## installation
```bash
pip install pynams